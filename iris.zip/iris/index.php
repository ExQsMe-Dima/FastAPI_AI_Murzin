<!DOCTYPE html>
<html>
<head>
    <title>Классификация ирисов</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }
        input:focus {
            border-color: #4CAF50;
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Определение вида ириса</h1>
    
    <form method="post" action="predict.php">
        <label>Длина чашелистика (cm):</label>
        <input type="number" step="any" name="sepal_length" placeholder="Например: 5.1" required>

        <label>Ширина чашелистика (cm):</label>
        <input type="number" step="any" name="sepal_width" placeholder="Например: 3.5" required>

        <label>Длина лепестка (cm):</label>
        <input type="number" step="any" name="petal_length" placeholder="Например: 1.4" required>

        <label>Ширина лепестка (cm):</label>
        <input type="number" step="any" name="petal_width" placeholder="Например: 0.2" required>

        <button type="submit">Определить вид</button>
    </form>
</body>
</html>