<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sepal_length = $_POST['sepal_length'];
    $sepal_width = $_POST['sepal_width'];
    $petal_length = $_POST['petal_length'];
    $petal_width = $_POST['petal_width'];

    $url = 'http://127.0.0.1:8000/predict';
    
    $data = http_build_query([
        'sepal_length' => $sepal_length,
        'sepal_width' => $sepal_width,
        'petal_length' => $petal_length,
        'petal_width' => $petal_width
    ]);

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => $data,
            'timeout' => 30
        ]
    ];

    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);
    
    if ($result === FALSE) {
        $error_message = "❌ Ошибка соединения с сервисом предсказания. Убедитесь, что FastAPI сервер запущен!";
    } else {
        $response = json_decode($result, true);
        $prediction = $response['prediction'] ?? 'ошибка';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Результат классификации</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .result-box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .params {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            text-align: left;
        }
        .params p {
            margin: 5px 0;
            color: #555;
        }
        .prediction {
            font-size: 32px;
            font-weight: bold;
            color: #4CAF50;
            margin: 20px 0;
            padding: 20px;
            background-color: #e8f5e9;
            border-radius: 5px;
        }
        .error {
            color: #f44336;
            background-color: #ffebee;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .button {
            display: inline-block;
            padding: 12px 30px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 20px;
        }
        .button:hover {
            background-color: #45a049;
        }
        .emoji {
            font-size: 24px;
        }
    </style>
</head>
<body>
    <h1>🌸 Результат классификации</h1>
    
    <div class="result-box">
        <?php if (isset($error_message)): ?>
            <div class="error">
                <div class="emoji">⚠️</div>
                <h3>Ошибка:</h3>
                <p><?php echo htmlspecialchars($error_message); ?></p>
            </div>
        <?php else: ?>
            <div class="params">
                <h3>📊 Введённые параметры:</h3>
                <p><strong>Длина чашелистика:</strong> <?php echo htmlspecialchars($sepal_length); ?> cm</p>
                <p><strong>Ширина чашелистика:</strong> <?php echo htmlspecialchars($sepal_width); ?> cm</p>
                <p><strong>Длина лепестка:</strong> <?php echo htmlspecialchars($petal_length); ?> cm</p>
                <p><strong>Ширина лепестка:</strong> <?php echo htmlspecialchars($petal_width); ?> cm</p>
            </div>
            
            <div class="prediction">
                <div class="emoji">🌺</div>
                <?php 
                $emoji = '';
                if ($prediction == 'setosa') $emoji = '🌸';
                else if ($prediction == 'versicolor') $emoji = '🌷';
                else if ($prediction == 'virginica') $emoji = '🌹';
                ?>
                <div><?php echo $emoji . ' ' . htmlspecialchars($prediction); ?></div>
            </div>
        <?php endif; ?>
        
        <a href="index.php" class="button">← Новое предсказание</a>
    </div>
</body>
</html>